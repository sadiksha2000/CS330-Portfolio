///////////////////////////////////////////////////////////////////////////////
// shadermanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// load every texture image used by the scene and give each a tag
	void LoadSceneTextures();

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

	// define the surface materials (how each part reflects light)
	void DefineObjectMaterials();

	// add one material to the material list; the ambient and diffuse values
	// are shared by every object, so only the highlight settings are passed
	void AddMaterial(
		std::string tag,
		glm::vec3 specularColor,
		float shininess);

	// add and configure the light sources of the scene
	void SetupSceneLights();

	// set the transformations and the color for one part of an
	// object; every part of the lamp is positioned through this
	void SetPartTransform(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ,
		glm::vec4 color);

	// draw the desk surface that the lamp sits on
	void RenderDeskSurface();

	// draw the notebook (a box) lying on the desk
	void RenderNotebook(glm::vec3 notebookPosition, float yRotationDegrees);

	// draw the mug (a cylinder body with a torus handle)
	void RenderMug(glm::vec3 mugPosition);

	// draw the glass paperweight (a sphere) resting on the desk
	void RenderPaperweight(glm::vec3 paperweightPosition);

	// draw the pencil (a cylinder body with a cone tip) lying on the desk
	void RenderPencil(glm::vec3 pencilPosition);

	// draw the desk lamp (the complex 3D object), built from a
	// cylinder base, a cylinder arm, and a tapered cylinder shade
	void RenderDeskLamp(glm::vec3 lampPosition);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

};
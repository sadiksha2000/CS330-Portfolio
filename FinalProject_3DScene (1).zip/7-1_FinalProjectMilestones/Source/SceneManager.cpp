///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MILESTONE TWO: complex 3D object (desk lamp) built from basic shapes
//  MILESTONE FOUR: textures mapped to the desk and to every lamp part
//  MILESTONE FIVE: lighting (lamp light, fill light, rim light) and materials
//  FINAL PROJECT: complete desk scene with five objects, textures, lights
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	// initialize the texture collection: every slot starts empty
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	// no textures are loaded yet; this counter must start at zero because
	// CreateGLTexture() uses it as the index of the next free texture slot
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads every image used to texture the scene
 *  and gives each one a tag (name). The tag is used later to
 *  choose the texture for a shape. The images come from the
 *  course textures folder, so no new files are needed.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// true when the image file was loaded successfully
	bool bReturn = false;

	// wood: tiled across the desk surface
	bReturn = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg",
		"desk_wood");

	// circular brushed brass: the lamp base (its top shows the radial grain)
	bReturn = CreateGLTexture(
		"../../Utilities/textures/circular-brushed-gold-texture.jpg",
		"base_brass");

	// brushed steel: the thin lamp arm
	bReturn = CreateGLTexture(
		"../../Utilities/textures/stainless.jpg",
		"arm_steel");

	// brushed gold: the lamp shade
	bReturn = CreateGLTexture(
		"../../Utilities/textures/gold-seamless-texture.jpg",
		"shade_gold");

	// abstract pattern: the notebook cover
	bReturn = CreateGLTexture(
		"../../Utilities/textures/abstract.jpg",
		"notebook_cover");

	// ceramic tile pattern: the mug body
	bReturn = CreateGLTexture(
		"../../Utilities/textures/tilesf2.jpg",
		"mug_ceramic");

	// stained glass: the glass paperweight
	bReturn = CreateGLTexture(
		"../../Utilities/textures/stainedglass.jpg",
		"paperweight_glass");

	// after the images are loaded into memory they need to be bound to
	// texture slots - there are 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines how each surface of the scene reacts
 *  to light. The desk gets a noticeable specular value so the
 *  lamp light reflects off its polished surface; the lamp
 *  parts get lower values because they are small and complex.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// polished wood desk: reflects a soft highlight of the lamp light
	OBJECT_MATERIAL deskMaterial;
	deskMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	deskMaterial.ambientStrength = 0.1f;
	deskMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	deskMaterial.specularColor = glm::vec3(0.5f, 0.45f, 0.4f);
	deskMaterial.shininess = 0.6f;
	deskMaterial.tag = "desk";
	m_objectMaterials.push_back(deskMaterial);

	// brushed brass lamp base: a moderate highlight
	OBJECT_MATERIAL brassMaterial;
	brassMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	brassMaterial.ambientStrength = 0.1f;
	brassMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	brassMaterial.specularColor = glm::vec3(0.4f, 0.35f, 0.25f);
	brassMaterial.shininess = 0.3f;
	brassMaterial.tag = "brass";
	m_objectMaterials.push_back(brassMaterial);

	// brushed steel lamp arm: a thin, slightly brighter highlight
	OBJECT_MATERIAL steelMaterial;
	steelMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	steelMaterial.ambientStrength = 0.1f;
	steelMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	steelMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	steelMaterial.shininess = 0.4f;
	steelMaterial.tag = "steel";
	m_objectMaterials.push_back(steelMaterial);

	// gold lamp shade: almost matte, since it is a complex shape
	OBJECT_MATERIAL shadeMaterial;
	shadeMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	shadeMaterial.ambientStrength = 0.1f;
	shadeMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	shadeMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	shadeMaterial.shininess = 0.1f;
	shadeMaterial.tag = "shade";
	m_objectMaterials.push_back(shadeMaterial);

	// the remaining desk objects share the same ambient and diffuse values,
	// so the helper only needs the highlight color and the shininess
	AddMaterial("paper", glm::vec3(0.05f, 0.05f, 0.05f), 0.05f);		// notebook: matte
	AddMaterial("ceramic", glm::vec3(0.5f, 0.5f, 0.5f), 0.5f);			// mug: glossy
	AddMaterial("glass", glm::vec3(0.8f, 0.8f, 0.8f), 0.9f);			// paperweight: very shiny
	AddMaterial("pencil", glm::vec3(0.1f, 0.1f, 0.1f), 0.1f);			// pencil: nearly matte
}

/***********************************************************
 *  AddMaterial()
 *
 *  This method creates a material with the shared ambient and
 *  diffuse values and the passed in specular color and
 *  shininess, then adds it to the list of defined materials.
 ***********************************************************/
void SceneManager::AddMaterial(
	std::string tag,
	glm::vec3 specularColor,
	float shininess)
{
	OBJECT_MATERIAL material;
	material.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	material.ambientStrength = 0.1f;
	material.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	material.specularColor = specularColor;
	material.shininess = shininess;
	material.tag = tag;
	m_objectMaterials.push_back(material);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures the light sources (up to four are
 *  supported by the shader). The scene uses three:
 *    0. a warm point light just under the lamp shade, which
 *       is the main light and matches the lamp in the scene
 *    1. a soft white fill light above and in front, so the
 *       lamp and the front of the desk are never in shadow
 *    2. a dim cool light behind the lamp, which lights the
 *       back edges of the parts
 *  The shader tints a light through its ambient color, so the
 *  warm lamp light has the strongest orange ambient value.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// tell the shader to use the custom lights; without this line
	// (or without any lights) the scene would be drawn flat
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// light 0: warm point light below the lamp shade opening
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.5f, 3.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.12f, 0.08f, 0.03f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 0.8f, 0.5f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 0.8f, 0.5f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 24.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.8f);

	// light 1: soft white fill light high in front of the lamp
	m_pShaderManager->setVec3Value("lightSources[1].position", -6.0f, 10.0f, 9.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.10f, 0.10f, 0.10f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

	// light 2: dim cool light behind the lamp (keeps the far side visible)
	m_pShaderManager->setVec3Value("lightSources[2].position", 6.0f, 6.0f, -6.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.05f, 0.06f, 0.09f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.4f, 0.45f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.3f, 0.3f, 0.4f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.1f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures used by the 3D scene
	LoadSceneTextures();

	// define the materials and add the lights used to light the scene
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// plane mesh: the desk surface
	m_basicMeshes->LoadPlaneMesh();
	// cylinder mesh: the lamp base and the lamp arm
	m_basicMeshes->LoadCylinderMesh();
	// tapered cylinder mesh: the lamp shade
	m_basicMeshes->LoadTaperedCylinderMesh();
	// box mesh: the notebook
	m_basicMeshes->LoadBoxMesh();
	// torus mesh: the mug handle
	m_basicMeshes->LoadTorusMesh();
	// sphere mesh: the paperweight
	m_basicMeshes->LoadSphereMesh();
	// cone mesh: the pencil tip
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  SetPartTransform()
 *
 *  This method sets the scale, rotation, and position of the
 *  next mesh to be drawn, then sets the color for it. It keeps
 *  the same order used for every shape: transform, color, draw.
 ***********************************************************/
void SceneManager::SetPartTransform(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ,
	glm::vec4 color)
{
	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	SetShaderColor(color.r, color.g, color.b, color.a);
}

/***********************************************************
 *  RenderDeskSurface()
 *
 *  This method draws the desk surface as a flat plane. The
 *  plane grounds the lamp, as described in the Milestone One
 *  proposal.
 ***********************************************************/
void SceneManager::RenderDeskSurface()
{
	// stretch the plane into a wide, shallow desk top, laid flat
	// (no rotation) with its top face at y = 0
	SetPartTransform(
		glm::vec3(20.0f, 1.0f, 10.0f),		// scale
		0.0f, 0.0f, 0.0f,					// rotation
		glm::vec3(0.0f, 0.0f, 0.0f),		// position
		glm::vec4(0.69f, 0.50f, 0.33f, 1.0f));	// wood brown

	// map the wood texture onto the desk; the plane is 20 by 10 units, so the
	// texture is tiled 4 by 2 times (TILING technique) to keep the wood grain
	// at a natural size instead of stretching one image over the whole desk
	SetShaderTexture("desk_wood");
	SetTextureUVScale(4.0f, 2.0f);

	// polished desk material so the lamp light reflects off the plane
	SetShaderMaterial("desk");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderDeskLamp()
 *
 *  This method draws the desk lamp, the complex object from
 *  the 2D scene, using three basic shapes:
 *    1. a short, wide cylinder for the base
 *    2. a tall, thin cylinder for the arm
 *    3. a tapered cylinder for the shade (wide end down)
 *  Each part is scaled first, then rotated, then translated.
 *  The lampPosition parameter is the center of the base on
 *  the desk, so the lamp can be moved without editing parts.
 ***********************************************************/
void SceneManager::RenderDeskLamp(glm::vec3 lampPosition)
{
	// ---- size of each part (scene units) ----
	const float baseRadius = 1.8f;
	const float baseHeight = 0.3f;
	const float armRadius = 0.12f;
	const float armHeight = 5.0f;
	const float shadeRadius = 1.7f;		// radius of the wide opening
	const float shadeHeight = 2.0f;
	const float shadeTiltDegrees = 10.0f;	// tilt of the shade on Z

	// ---- colors ----
	const glm::vec4 baseColor(0.20f, 0.22f, 0.27f, 1.0f);	// dark slate
	const glm::vec4 armColor(0.24f, 0.27f, 0.33f, 1.0f);	// lighter slate
	const glm::vec4 shadeColor(0.84f, 0.66f, 0.24f, 1.0f);	// gold
	const glm::vec4 glowColor(0.98f, 0.92f, 0.67f, 1.0f);	// lit opening

	/*** BASE: short, wide cylinder resting on the desk.            ***/
	/*** The cylinder mesh starts at y = 0, so the lamp position    ***/
	/*** is used as is and the base sits on the desk surface.       ***/
	/******************************************************************/
	SetPartTransform(
		glm::vec3(baseRadius, baseHeight, baseRadius),
		0.0f, 0.0f, 0.0f,
		lampPosition,
		baseColor);
	// brass texture on the base; the side is tiled 3 times around because the
	// base is very wide and short, and the top cap shows the circular grain
	SetShaderTexture("base_brass");
	SetTextureUVScale(3.0f, 1.0f);
	// brass material for the base
	SetShaderMaterial("brass");

	m_basicMeshes->DrawCylinderMesh();

	/*** ARM: tall, thin cylinder standing on the middle of the base. ***/
	/*** It is raised by the base height so it starts on top of it.   ***/
	/******************************************************************/
	glm::vec3 armPosition = lampPosition + glm::vec3(0.0f, baseHeight, 0.0f);
	SetPartTransform(
		glm::vec3(armRadius, armHeight, armRadius),
		0.0f, 0.0f, 0.0f,
		armPosition,
		armColor);
	// steel texture on the arm; the arm is tall and thin, so the texture is
	// tiled 6 times along its length to avoid a stretched, blurry look
	SetShaderTexture("arm_steel");
	SetTextureUVScale(1.0f, 6.0f);
	// steel material for the arm
	SetShaderMaterial("steel");

	m_basicMeshes->DrawCylinderMesh();

	/*** SHADE: tapered cylinder, wide end down, tilted on Z so the  ***/
	/*** light points toward the desk. Its top center is placed on   ***/
	/*** the top of the arm.                                         ***/
	/******************************************************************/
	// top center of the arm, where the shade attaches
	glm::vec3 armTop = armPosition + glm::vec3(0.0f, armHeight, 0.0f);

	// direction the shade's axis points after the Z tilt (from its
	// bottom center toward its top center); uses the same rotation
	// that SetTransformations() applies to the mesh
	glm::vec3 shadeAxis = glm::vec3(
		glm::rotate(glm::radians(shadeTiltDegrees), glm::vec3(0.0f, 0.0f, 1.0f))
		* glm::vec4(0.0f, 1.0f, 0.0f, 0.0f));

	// the mesh origin is the bottom center of the shade, so back up
	// from the arm top by the shade height along the tilted axis
	glm::vec3 shadePosition = armTop - shadeAxis * shadeHeight;

	SetPartTransform(
		glm::vec3(shadeRadius, shadeHeight, shadeRadius),
		0.0f, 0.0f, shadeTiltDegrees,
		shadePosition,
		shadeColor);
	// gold texture on the sides and top of the shade, tiled 3 times around
	SetShaderTexture("shade_gold");
	SetTextureUVScale(3.0f, 1.0f);
	// nearly matte gold material for the shade
	SetShaderMaterial("shade");

	m_basicMeshes->DrawTaperedCylinderMesh(true, false, true);

	// draw only the bottom opening in a plain pale color so it looks lit;
	// SetShaderColor turns texturing off, and the transformation set above
	// is reused for this draw
	SetShaderColor(glowColor.r, glowColor.g, glowColor.b, glowColor.a);
	m_basicMeshes->DrawTaperedCylinderMesh(false, true, false);
}

/***********************************************************
 *  RenderNotebook()
 *
 *  This method draws the notebook as a flat box lying on the
 *  desk. The box mesh is centered on its origin, so it is
 *  raised by half its thickness to rest on the desk surface.
 ***********************************************************/
void SceneManager::RenderNotebook(glm::vec3 notebookPosition, float yRotationDegrees)
{
	const glm::vec3 notebookSize(3.0f, 0.25f, 4.0f);	// width, thickness, length

	SetPartTransform(
		notebookSize,
		0.0f, yRotationDegrees, 0.0f,
		notebookPosition + glm::vec3(0.0f, notebookSize.y / 2.0f, 0.0f),
		glm::vec4(0.6f, 0.6f, 0.8f, 1.0f));
	// abstract cover texture, one copy over the whole cover
	SetShaderTexture("notebook_cover");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMug()
 *
 *  This method draws the mug from two shapes:
 *    1. a cylinder for the body
 *    2. a torus for the handle, on the right side of the body
 *  The mugPosition parameter is the center of the mug bottom.
 ***********************************************************/
void SceneManager::RenderMug(glm::vec3 mugPosition)
{
	const float mugRadius = 0.8f;
	const float mugHeight = 1.4f;

	// body: the cylinder mesh starts at y = 0, so it sits on the desk as is
	SetPartTransform(
		glm::vec3(mugRadius, mugHeight, mugRadius),
		0.0f, 0.0f, 0.0f,
		mugPosition,
		glm::vec4(0.8f, 0.8f, 0.85f, 1.0f));
	SetShaderTexture("mug_ceramic");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh();

	// handle: a small torus standing on its side against the body,
	// halfway up, so it reads as a loop from the front
	SetPartTransform(
		glm::vec3(0.4f, 0.4f, 0.4f),
		0.0f, 0.0f, 0.0f,
		mugPosition + glm::vec3(mugRadius + 0.2f, mugHeight / 2.0f, 0.0f),
		glm::vec4(0.8f, 0.8f, 0.85f, 1.0f));
	SetShaderTexture("mug_ceramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 *  RenderPaperweight()
 *
 *  This method draws the glass paperweight as a sphere. The
 *  sphere mesh has a radius of one unit and is centered on its
 *  origin, so it is raised by its scaled radius to rest on the
 *  desk.
 ***********************************************************/
void SceneManager::RenderPaperweight(glm::vec3 paperweightPosition)
{
	const float paperweightRadius = 0.55f;

	SetPartTransform(
		glm::vec3(paperweightRadius, paperweightRadius, paperweightRadius),
		0.0f, 0.0f, 0.0f,
		paperweightPosition + glm::vec3(0.0f, paperweightRadius, 0.0f),
		glm::vec4(0.7f, 0.85f, 0.9f, 1.0f));
	SetShaderTexture("paperweight_glass");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  RenderPencil()
 *
 *  This method draws a pencil lying along the X axis from two
 *  shapes:
 *    1. a thin cylinder for the body
 *    2. a cone for the sharpened tip at the +X end
 *  Rotating -90 degrees on Z turns the mesh's upward axis into
 *  the +X direction. The pencilPosition parameter is the back
 *  end of the pencil on the desk.
 ***********************************************************/
void SceneManager::RenderPencil(glm::vec3 pencilPosition)
{
	const float pencilRadius = 0.1f;
	const float bodyLength = 2.4f;
	const float tipLength = 0.4f;

	// body: lifted by its radius so it rests on the desk
	glm::vec3 bodyPosition = pencilPosition + glm::vec3(0.0f, pencilRadius, 0.0f);
	SetPartTransform(
		glm::vec3(pencilRadius, bodyLength, pencilRadius),
		0.0f, 0.0f, -90.0f,
		bodyPosition,
		glm::vec4(0.95f, 0.8f, 0.2f, 1.0f));		// yellow paint
	SetShaderMaterial("pencil");
	m_basicMeshes->DrawCylinderMesh();

	// tip: starts where the body ends and points further along +X
	SetPartTransform(
		glm::vec3(pencilRadius, tipLength, pencilRadius),
		0.0f, 0.0f, -90.0f,
		bodyPosition + glm::vec3(bodyLength, 0.0f, 0.0f),
		glm::vec4(0.85f, 0.65f, 0.45f, 1.0f));	// bare wood
	SetShaderMaterial("pencil");
	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// draw the desk surface that grounds the scene
	RenderDeskSurface();

	// draw the desk lamp standing at the center of the desk
	RenderDeskLamp(glm::vec3(0.0f, 0.0f, 0.0f));

	// draw the other desk objects around the lamp, in front of it
	RenderNotebook(glm::vec3(5.2f, 0.0f, 1.8f), 20.0f);
	RenderMug(glm::vec3(-4.5f, 0.0f, 2.0f));
	RenderPaperweight(glm::vec3(2.4f, 0.0f, 3.4f));
	RenderPencil(glm::vec3(-2.6f, 0.0f, 4.2f));
}

CS-330 Final Project: Desk Scene - Sadiksha Pathak

Run: open 7-1_FinalProjectMilestones\Debug\7-1_FinalProjectMilestones.exe (glew32.dll and glfw3.dll are beside it).
Controls: W/A/S/D move, Q/E up/down, mouse looks around, scroll changes speed, P perspective, O orthographic, Esc quits.
Objects: desk plane, lamp, notebook, mug, paperweight, pencil.
Source: 7-1_FinalProjectMilestones\Source. Project: 7-1_FinalProjectMilestones.sln (Visual Studio 2022).
